import React from 'react';

const YearText = ({register,errors})=>{
       return <div className="form__control">
       <div className="form__unit">
                  <select name="year" type="text" className="form__input" ref={register({
                  	required:true,
                  	maxLength:4
                  	})} placeholder=" " autoComplete="off">
                           <option value="final_year" className="form__label">Final Year</option>
                           <option value="third_year" className="form__label">Third Year</option>
                            <option value="second_year" className="form__label">Second year</option>
                            <option value="first_year" className="form__label">First Year</option>
                      </select>
                    <label for='year' className="form__label">Year Arrived</label>
                   
                     </div>
                     
                  {errors &&<div className="form__error">Invalid year input</div>}
                  

               </div>
}

export default YearText;