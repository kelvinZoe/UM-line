import React from 'react'
const Test = (props)=>{
	console.log(props)
	return <div>hey</div>
}
export default Test